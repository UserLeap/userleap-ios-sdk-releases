//
//  UserLeapKit.h
//  UserLeap
//
//  Copyright © 2019 UserLeap. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for UserLeapSDK.
FOUNDATION_EXPORT double UserLeapVersionNumber;

//! Project version string for UserLeapSDK.
FOUNDATION_EXPORT const unsigned char UserLeapVersionString[];


